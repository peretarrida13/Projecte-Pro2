var searchData=
[
  ['imprime_5farbol_5ffilogenetio',['imprime_arbol_filogenetio',['../class_cjt___cluster.html#a725d16b2451708683c6f670d8139968b',1,'Cjt_Cluster']]],
  ['imprime_5fcjt_5fespecies',['imprime_cjt_especies',['../class_cjt___especies.html#a5cdac56c0c7e5ba8b2f954018a84ad4f',1,'Cjt_Especies']]],
  ['imprimeix_5fcluster',['imprimeix_cluster',['../class_cluster.html#ad6724843dfb6efda89fcd0889d1aeaa3',1,'Cluster']]],
  ['imprimir_5ftabla_5fdistancias',['imprimir_tabla_distancias',['../class_cjt___especies.html#a49b29e95694d85c2db4640398e5e8667',1,'Cjt_Especies']]],
  ['inicialitza_5fclustrers',['inicialitza_clustrers',['../class_cjt___cluster.html#a84fffe9aace21033dfaf9958286f9ae8',1,'Cjt_Cluster']]]
];
