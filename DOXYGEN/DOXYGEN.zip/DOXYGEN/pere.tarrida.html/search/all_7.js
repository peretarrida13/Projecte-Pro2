var searchData=
[
  ['obtener_5fgen',['obtener_gen',['../class_especie.html#a42208792caa6c859179be0439a34814e',1,'Especie']]],
  ['obtener_5fkmer',['obtener_kmer',['../class_especie.html#a477917049aeb4f87230d840d4a3d021d',1,'Especie']]]
];
