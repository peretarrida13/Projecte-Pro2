var searchData=
[
  ['especie',['Especie',['../class_especie.html',1,'']]],
  ['espècie',['Espècie',['../class_esp_xC3_xA8cie.html',1,'']]]
];
